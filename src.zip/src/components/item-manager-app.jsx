import "./item-manager-app.css";

import { useState, useRef } from "react";

import deleteLogo from "../assets/delete.svg";
import stationaryLogo from "../assets/ink_pen.svg";
import kitchenwareLogo from "../assets/flatware.svg";
import applianceLogo from "../assets/electrical_services.svg";

function ItemManager() {
  /*
   * !!! IMPORTANT !!!
   * - You MUST use the given states and refs in your code.
   * - You MAY add additional state, refs, and variables if needed.
   */

  const [items, setItems] = useState([]);
  const [errorMsg, setErrorMsg] = useState("");

  const [category, setCategory] = useState("");
  const [price, setPrice] = useState("");
  const [nextId, setNextId] = useState(1);

  // You must use this ref for the item name input
  const itemName = useRef(null);

  const categoryIcons = {
    Stationary: stationaryLogo,
    Kitchenware: kitchenwareLogo,
    Appliance: applianceLogo
  };

  const addItem = () => {
    setErrorMsg("");

    const name = itemName.current.value.trim();

    if (name === "") {
      setErrorMsg("Item name must not be empty");
      return;
    }

    if (items.some(i => i.name.toLowerCase() === name.toLowerCase())) {
      setErrorMsg("Item must not be duplicated");
      return;
    }

    if (category === "") {
      setErrorMsg("Please select a category");
      return;
    }

    if (price < 0) {
      setErrorMsg("Price must not be less than 0");
      return;
    }

    setItems([
      ...items,
      {
        id: nextId,
        name,
        category,
        price
      }
    ]);

    setNextId(nextId + 1);
    itemName.current.value = "";
    setCategory("");
    setPrice("");
  };

  const deleteItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  return (
    <>
      <div id="h1">Item Management</div>

      <div id="data-area">
        <table id="item-table" className="item-table">
          <thead>
            <tr>
              <th id="col-item-id">ID</th>
              <th id="col-item-name">Name</th>
              <th id="col-item-category">Category</th>
              <th id="col-item-price">Price</th>
              <th id="col-item-action">Action</th>
            </tr>
          </thead>

          <tbody>
            {/* Existing items */}
            {items.map(item => (
              <tr key={item.id}>
                <td>{item.id}</td>
                <td>{item.name}</td>
                <td>
                  <img src={categoryIcons[item.category]} alt={item.category} />
                </td>
                <td>{item.price}</td>
                <td>
                  <img
                    src={deleteLogo}
                    alt="delete"
                    style={{ cursor: "pointer" }}
                    onClick={() => deleteItem(item.id)}
                  />
                </td>
              </tr>
            ))}

            {/* Input form row (LAST ROW) */}
            <tr>
              <td></td>
              <td>
                <input ref={itemName} />
              </td>
              <td>
                <select
                  value={category}
                  onChange={e => setCategory(e.target.value)}
                >
                  <option value="">Select</option>
                  <option value="Stationary">Stationary</option>
                  <option value="Kitchenware">Kitchenware</option>
                  <option value="Appliance">Appliance</option>
                </select>
              </td>
              <td>
                <input
                  type="number"
                  value={price}
                  onChange={e => setPrice(e.target.value)}
                />
              </td>
              <td>
                <button onClick={addItem}>Add Item</button>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <div id="error-message">
        {errorMsg}
      </div>
    </>
  );
}

export default ItemManager;
