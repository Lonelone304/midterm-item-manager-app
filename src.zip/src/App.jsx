import ItemManager from "./components/item-manager-app"

function App() {
  return (
    <ItemManager/>
  )
}

export default App
